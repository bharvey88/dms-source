// __DMS_Sherline_Lathe_Test_Spindle.c
// Last revised 19 Nov. 2025

#include "KMotionDef.h"
#include "__DMS_Sherline_Lathe_Config.h"
	
	// Observed Values with Stock Motor
	// 8 = 47 rpm (LOWEST RPM WITHOUT STUTTER - DO NOT ALLOW LOWER)
	// 12 = 99 rpm
	// 16 = 151 rpm
	// 24 = 253 rpm
	// 32 = 363 rpm
	// 48 = 568 rpm
	// 64 = 775 rpm
	// 80 = 990 rpm
	// 96 = 1195 rpm
	// 112 = 1418 rpm
	// 128 = 1623 rpm
	// 144 = 1848 rpm
	// 160 = 2053 rpm
	// 176 = 2277 rpm
	// 192 = 2483 rpm
	// 208 = 2709 rpm
	// 224 = 2905 rpm
	// 240 = 3132 rpm
	// 255 = 3325 rpm (~100% DUTY CYCLE)

void main {

	RunIncrementTest();
	
}

void RunIncrementTest() {

	FPGA(IO_PWMS) = 12;
	StartSpindle();
	
	const int speeds[9] = { 400, 800, 1000, 1200, 1600, 2000, 2400, 2800, 3200 };
	
	int speed_setting;
	for (speed_setting = 0; speed_setting < 9; speed_setting++) {
		const int rpm = speeds[speed_setting];
		const int duty = ConvertRpmToDutyCycle(rpm);
		printf("Setting duty cycle to %i to achieve goal RPM of %i\n", duty, rpm);
		
		FPGA(IO_PWMS) = duty;
		Delay_sec(10);
	}
	
	StopSpindle();
	
}

void StartSpindle() {
	SetBit(SPINDLE_ENABLE);
	// FPGA(PWM_ENABLED) = 1;
}

void StopSpindle() {
	ClearBit(SPINDLE_ENABLE);
	// FPGA(PWM_DUTY_CYCLE) = 0;
	// FPGA(PWM_ENABLED) = 0;
}

void CheckCalculations(int rpm) {
	const int duty = ConvertRpmToDutyCycle(rpm);
	const int rpmOut = ConvertDutyCycleToRPM(duty);
	printf("RPM %i corresponds to duty cycle %i\n", rpm, duty);
	printf("Duty cycle %i corresponds to RPM %i\n", duty, rpmOut);
}

int ConvertRpmToDutyCycle(int rpm) {
	const float fRPM = (float)rpm;
	const float fDuty = (fRPM + 67.7f) / 13.3f;
	int iDutyTruncated = (int)fDuty;
	const float remainder = fDuty - iDutyTruncated;
	if (remainder >= 0.5f) iDutyTruncated++;
	return iDutyTruncated;
}

int ConvertDutyCycleToRPM(int duty) {
	const float fDuty = (float)duty;
	const float fRPM = (fDuty * 13.3f) - 67.7f;
	int iRpmTruncated = (int)fRPM;
	const float remainder = fRPM - iRpmTruncated;
	if (remainder >= 0.5f) iRpmTruncated++;
	return iRpmTruncated;
}
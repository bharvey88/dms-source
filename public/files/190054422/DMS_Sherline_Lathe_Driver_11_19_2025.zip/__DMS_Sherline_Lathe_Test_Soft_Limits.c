// __DMS_Sherline_Lathe_Test_Soft_Limits.c
// Last revised 19 Nov. 2025

#include "KMotionDef.h"
#include "__DMS_Sherline_Lathe_Config.h"

void main()
{
	// TestAxis(0);
	// TestAxis(1);
	
	// DoWiggle(Z_AXIS_CHANNEL);
	// DoWiggle(X_AXIS_CHANNEL);
	
	//DoTestHardStops();
	DoTestSoftLimitsPositive();
	
	// MoveRelAtVel(Z_AXIS_CHANNEL, -0.0625, FULL_RAPID);
}

void DoMoveLeft() {
	MoveRelAtVel(Z_AXIS_CHANNEL, -1, FULL_RAPID);
}

void DoMoveRight() {
	MoveRelAtVel(Z_AXIS_CHANNEL, 1, FULL_RAPID);
}

void DoMoveRadialIn() {
	MoveRelAtVel(X_AXIS_CHANNEL, -1, FULL_RAPID);
}

void DoMoveRadialOut() {
	MoveRelAtVel(X_AXIS_CHANNEL, 1, FULL_RAPID);
}

void DoWiggle(int axis) {
	
	MoveRelAtVel(axis, -1, FULL_RAPID);
	while (!CheckDone(axis));
	MoveRelAtVel(axis, 1, FULL_RAPID);
	while (!CheckDone(axis));
	MoveRelAtVel(axis, -1, FULL_RAPID);
	while (!CheckDone(axis));
	MoveRelAtVel(axis, 1, FULL_RAPID);
	while (!CheckDone(axis));
	
}

void DoTestHardStops() {

	const CHAN *Z_AXIS = &(chan[Z_AXIS_CHANNEL]);
	const CHAN *X_AXIS = &(chan[X_AXIS_CHANNEL]);
	
	const soft_limit_negative_z = Z_AXIS->SoftLimitNeg;
	const soft_limit_positive_z = Z_AXIS->SoftLimitPos;
	const soft_limit_negative_x = X_AXIS->SoftLimitNeg;
	const soft_limit_positive_x = X_AXIS->SoftLimitPos;
	
	Z_AXIS->SoftLimitNeg = -2.0e9;
	Z_AXIS->SoftLimitPos = 2.0e9;
	X_AXIS->SoftLimitNeg = -2.0e9;
	X_AXIS->SoftLimitPos = 2.0e9;
	
	DoReelBack();	
	DoChargeAtPosition(0.125, 0.125);
	
	Z_AXIS->SoftLimitNeg = soft_limit_negative_z;
	Z_AXIS->SoftLimitPos = soft_limit_positive_z;
	X_AXIS->SoftLimitNeg = soft_limit_negative_x;
	X_AXIS->SoftLimitPos = soft_limit_positive_x;
	
}

void DoTestSoftLimitsPositive() {

	DoReelBack();
	DoChargeAtPosition(0.125, 0.125);

}

void DoReelBack() {

	DoMoveLeft();
	while(!CheckDone(0));
	DoMoveLeft();
	DoMoveRadialIn();
	
	while(!CheckDone(0) || !CheckDone(1));

}

void DoChargeAtPosition(float x_pos, float z_pos) {

	MoveAtVel(Z_AXIS_CHANNEL, z_pos, FULL_RAPID);
	MoveAtVel(X_AXIS_CHANNEL, x_pos, FULL_RAPID);
	
	while(!CheckDone(0) || !CheckDone(1));

}
// __DMS_Sherline_Lathe_Init.c
// Last revised 19 Nov. 2025

#include "KMotionDef.h"
#include "__DMS_Sherline_Lathe_Config.h"

void main()
{
	printf("DMS Sherline lathe configuration reloaded.\n");
	
	// Channel 0 (Z axis)
	ch0->InputMode=NO_INPUT_MODE;
	ch0->OutputMode=STEP_DIR_MODE;
	ch0->Vel=40000;
	ch0->Accel=400000;
	ch0->Jerk=4e+06;
	ch0->P=0;
	ch0->I=0.01;
	ch0->D=0;
	ch0->FFAccel=0;
	ch0->FFVel=0;
	ch0->MaxI=200;
	ch0->MaxErr=1e+06;
	ch0->MaxOutput=200;
	ch0->DeadBandGain=1;
	ch0->DeadBandRange=0;
	ch0->InputChan0=4;
	ch0->InputChan1=0;
	ch0->OutputChan0=8;
	ch0->OutputChan1=0;
	ch0->MasterAxis=-1;
	ch0->LimitSwitchOptions=0x112;
	ch0->LimitSwitchNegBit=0;
	ch0->LimitSwitchPosBit=4;
	ch0->SoftLimitPos=-0.5;
	ch0->SoftLimitNeg=-2e+09;
	ch0->InputGain0=1;
	ch0->InputGain1=1;
	ch0->InputOffset0=0;
	ch0->InputOffset1=0;
	ch0->OutputGain=-806400;
	ch0->OutputOffset=40000;
	ch0->SlaveGain=1;
	ch0->BacklashMode=BACKLASH_OFF;
	ch0->BacklashAmount=0;
	ch0->BacklashRate=0;
	ch0->invDistPerCycle=1;
	ch0->Lead=0;
	ch0->MaxFollowingError=1000000000;
	ch0->StepperAmplitude=20;

	ch0->iir[0].B0=1;
	ch0->iir[0].B1=0;
	ch0->iir[0].B2=0;
	ch0->iir[0].A1=0;
	ch0->iir[0].A2=0;

	ch0->iir[1].B0=1;
	ch0->iir[1].B1=0;
	ch0->iir[1].B2=0;
	ch0->iir[1].A1=0;
	ch0->iir[1].A2=0;

	ch0->iir[2].B0=0.000769;
	ch0->iir[2].B1=0.001538;
	ch0->iir[2].B2=0.000769;
	ch0->iir[2].A1=1.92081;
	ch0->iir[2].A2=-0.923885;

	// Channel 1 (Y axis)
	ch1->InputMode=NO_INPUT_MODE;
	ch1->OutputMode=STEP_DIR_MODE;
	ch1->Vel=40000;
	ch1->Accel=400000;
	ch1->Jerk=4e+06;
	ch1->P=0;
	ch1->I=0.01;
	ch1->D=0;
	ch1->FFAccel=0;
	ch1->FFVel=0;
	ch1->MaxI=200;
	ch1->MaxErr=1e+06;
	ch1->MaxOutput=200;
	ch1->DeadBandGain=1;
	ch1->DeadBandRange=0;
	ch1->InputChan0=5;
	ch1->InputChan1=0;
	ch1->OutputChan0=9;
	ch1->OutputChan1=0;
	ch1->MasterAxis=-1;
	ch1->LimitSwitchOptions=0x112;
	ch1->LimitSwitchNegBit=0;
	ch1->LimitSwitchPosBit=5;
	ch1->SoftLimitPos=-0.0625;
	ch1->SoftLimitNeg=-2e+09;
	ch1->InputGain0=1;
	ch1->InputGain1=1;
	ch1->InputOffset0=0;
	ch1->InputOffset1=0;
	ch1->OutputGain=806400;
	ch1->OutputOffset=0;
	ch1->SlaveGain=1;
	ch1->BacklashMode=BACKLASH_OFF;
	ch1->BacklashAmount=0;
	ch1->BacklashRate=0;
	ch1->invDistPerCycle=1;
	ch1->Lead=0;
	ch1->MaxFollowingError=1000000000;
	ch1->StepperAmplitude=20;

	ch1->iir[0].B0=1;
	ch1->iir[0].B1=0;
	ch1->iir[0].B2=0;
	ch1->iir[0].A1=0;
	ch1->iir[0].A2=0;

	ch1->iir[1].B0=1;
	ch1->iir[1].B1=0;
	ch1->iir[1].B2=0;
	ch1->iir[1].A1=0;
	ch1->iir[1].A2=0;

	ch1->iir[2].B0=0.000769;
	ch1->iir[2].B1=0.001538;
	ch1->iir[2].B2=0.000769;
	ch1->iir[2].A1=1.92081;
	ch1->iir[2].A2=-0.923885;

	// Channel 2 (Spindle?)
	// JP7 Pin 13 (purple wire) -> spindle on/off (+3.3V = ON)
	// JP7 Pin 5 (brown wire) -> spindle speed (+0V = 0 rpm, +3.3V = ???)
	ch2->InputMode=NO_INPUT_MODE;
	ch2->OutputMode=NO_OUTPUT_MODE;
	
	SetBitDirection(SPINDLE_ENABLE,1);
	SetBitDirection(SPINDLE_SPEED,1);
	FPGA(KAN_TRIG_REG) = 4;				// Move PWM output to pin 5 on JP7
	//FPGA(PWM_FREQUENCY_SETTING) = 4;	// Set PWM frequency to 13 KHz
	//FPGA(PWM_ENABLED) = 1;
	FPGA(IO_PWMS_PRESCALE) = 4;
	FPGA(IO_PWMS) = 128;
	FPGA(IO_PWMS+1) = 1;
	
	EnableAxis(0);
	EnableAxis(1);
	DisableAxis(2); // ?
	
	for(;;) {
		DoServiceTask1();
		WaitNextTimeSlice();
		// WaitUntil();
	}
	
}

void DoServiceTask1() {
	// Something here...
}
// __DMS_Sherline_Lathe_Config.h
// Last revised 19 Nov. 2025

// Define Input/Output Channels
#define X_AXIS_CHANNEL 1
#define Z_AXIS_CHANNEL 0
#define X_AXIS_LIM_SWITCH 5
#define Z_AXIS_LIM_SWITCH 4

// Define Spindle Control Channels
#define SPINDLE_ENABLE 6
#define SPINDLE_SPEED 44

// Define Movement Directions
#define RADIAL_IN -1   			// -X
#define RADIAL_OUT 1			// +X
#define CROSS_SLIDE_LEFT -1		// -Z
#define CROSS_SLIDE_RIGHT 1		// +Z
#define CROSS_SLIDE_AWAY RADIAL_IN
#define CROSS_SLIDE_CLOSER RADIAL_OUT

// Define Jog Rates
#define STOP 0
#define FULL_RAPID 0.35

// Define Soft Limits
#define X_SOFT_LIMIT_POS -0.0625
#define X_SOFT_LIMIT_NEG -2e9
#define Z_SOFT_LIMIT_POS -0.0625
#define Z_SOFT_LIMIT_NEG -2e9

// FPGA Register Names [DO NOT EDIT]
#define PWM_DUTY_CYCLE IO_PWMS
#define PWM_ENABLED IO_PWMS + 1
#define PWM_FREQUENCY_SETTING IO_PWMS_PRESCALE
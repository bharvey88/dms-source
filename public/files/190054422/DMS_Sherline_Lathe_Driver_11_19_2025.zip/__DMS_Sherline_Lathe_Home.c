// __DMS_Sherline_Lathe_Home.c
// Last revised 19 Nov. 2025

#include "KMotionDef.h"
#include "__DMS_Sherline_Lathe_Config.h"

// Define Touch-Off Parameters
#define SLOW_JOG 0.02 // inches per second
#define MEDIUM_JOG 0.15 // inches per second
#define RETOUCH_BACK_OFF_DIST 0.03125 // inches
#define FINAL_BACK_OFF_DIST 0.25 // inches

typedef struct {
	int channel;
	int lim_switch;
	int initial_dir;
} Axis;

void main()
{	
	const Axis X_AXIS = {
		X_AXIS_CHANNEL,
		X_AXIS_LIM_SWITCH,
		CROSS_SLIDE_CLOSER
	};

	const Axis Z_AXIS = {
		Z_AXIS_CHANNEL,
		Z_AXIS_LIM_SWITCH,
		CROSS_SLIDE_RIGHT
	};
	
	printf("Beginning home routine...\n");
	
	HomeAxis(&Z_AXIS);
	HomeAxis(&X_AXIS);
	
	printf("Home routine finished.\n");
}

void HomeAxis(Axis *axis) {
	const CHAN *CONFIG = &(chan[axis->channel]);
	const FEED_IN = axis->initial_dir;
	const FEED_OUT = axis->initial_dir * -1;
	
	// Disable soft and hard stops to allow driving past limits
	const hard_limit_flags = CONFIG->LimitSwitchOptions;
	const soft_limit_negative = CONFIG->SoftLimitNeg;
	const soft_limit_positive = CONFIG->SoftLimitPos;
	CONFIG->LimitSwitchOptions = 0x000;
	CONFIG->SoftLimitNeg = -2.0e9;
	CONFIG->SoftLimitPos = 2.0e9;
	printf("Warning: Hard stop temporarily disabled on axis %i.\n", axis->channel);
	
	// Re-enable axis in case it was already killed by the hard stop
	EnableAxis(axis->channel);

	// Rapid to limit switch or back off fully if already engaged
	if (!ReadBit(axis->lim_switch)) {
		Jog(axis->channel, FULL_RAPID * FEED_IN);
		while(!ReadBit(axis->lim_switch));
	} else {
		Jog(axis->channel, MEDIUM_JOG * FEED_OUT);
		while(ReadBit(axis->lim_switch));
	}
	
	// Back off switch by set distance
	MoveRelAtVel(axis->channel, RETOUCH_BACK_OFF_DIST * FEED_OUT, MEDIUM_JOG);
	while(!CheckDone(axis->channel));
	
	// Slow jog back onto switch
	Jog(axis->channel, SLOW_JOG * FEED_IN);
	while(!ReadBit(axis->lim_switch));
	Jog(axis->channel, STOP);
	while(!CheckDone(axis->channel));
	
	// Set zero point for axis
	Zero(axis->channel);
	
	// Back off limit switch by final distance
	MoveRelAtVel(axis->channel, FINAL_BACK_OFF_DIST * FEED_OUT, MEDIUM_JOG);
	while(!CheckDone(axis->channel));
	
	// Restore soft and hard stop limits
	CONFIG->LimitSwitchOptions = hard_limit_flags;
	CONFIG->SoftLimitNeg = soft_limit_negative;
	CONFIG->SoftLimitPos = soft_limit_positive;
	printf("OK: Hard stop restored on axis %i (options 0x%x)\n", axis-> channel, CONFIG->LimitSwitchOptions);
}
